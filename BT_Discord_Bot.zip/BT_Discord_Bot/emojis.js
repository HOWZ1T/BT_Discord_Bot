﻿module.exports.emojis = {
    lightsaber: '<:lightsaber:382751768414650369>',
    c3po: '<:c3po:382751768682954752>',
    bb8: '<:bb8:382751768704057344>',
    stormtrooper: '<:stormtrooper:382751768901058580>',
    porg: '<:porg:382751770411008002>',
    chewbacca: '<:chewbacca:382751770733969408>',
    credits: '<:credits:382752919101112323>',
    arrowleft: '<:arrowleft:382752919839178752>',
    arrowright: '<:arrowright:382752920153882634>',
    empty: '<:empty:382848830607065089>'
};

module.exports.slotsMap = {
    0: '<:lightsaber:382751768414650369>',
    1: '<:c3po:382751768682954752>',
    2: '<:bb8:382751768704057344>',
    3: '<:stormtrooper:382751768901058580>',
    4: '<:porg:382751770411008002>',
    5: '<:chewbacca:382751770733969408>'
}