﻿module.exports.thumbs = {
    common: 'http://i.imgur.com/IZfhab3.png',
    uncommon: 'http://i.imgur.com/Pon76WA.png',
    rare: 'http://i.imgur.com/gl0InnG.png',
    legendary: 'http://i.imgur.com/UvJEEa5.png'
};

module.exports.thumbsArr = ["http://i.imgur.com/UvJEEa5.png", "http://i.imgur.com/gl0InnG.png", "http://i.imgur.com/Pon76WA.png", "http://i.imgur.com/IZfhab3.png"];